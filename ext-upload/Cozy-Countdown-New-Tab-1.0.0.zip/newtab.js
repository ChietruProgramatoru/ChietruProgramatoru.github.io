// Cozy Countdown New Tab. Settings live in this browser's localStorage only. No network requests.
(function () {
  var $ = function (i) { return document.getElementById(i); };
  function load() {
    try { return Object.assign({ ev: "christmas", cName: "", cDate: "", theme: "auto", showSupport: true, flen: 25 }, JSON.parse(localStorage.getItem("cc") || "{}")); }
    catch (e) { return { ev: "christmas", theme: "auto", showSupport: true, flen: 25 }; }
  }
  var cfg = load();
  function save() { try { localStorage.setItem("cc", JSON.stringify(cfg)); } catch (e) {} }
  function pad(n) { return String(n).padStart(2, "0"); }

  function target() {
    var now = new Date(), y = now.getFullYear();
    if (cfg.ev === "newyear") return { name: "New Year " + (y + 1), t: new Date(y + 1, 0, 1) };
    if (cfg.ev === "custom" && /^\d{4}-\d{2}-\d{2}$/.test(cfg.cDate)) {
      var p = cfg.cDate.split("-");
      return { name: cfg.cName || "My day", t: new Date(+p[0], p[1] - 1, +p[2]) };
    }
    var x = new Date(y, 11, 25);
    if (now >= new Date(y, 11, 26)) x = new Date(y + 1, 11, 25);
    return { name: "Christmas " + x.getFullYear(), t: x };
  }

  function applyTheme() {
    if (cfg.theme === "auto") document.documentElement.removeAttribute("data-theme");
    else document.documentElement.setAttribute("data-theme", cfg.theme);
    $("support").hidden = !cfg.showSupport;
  }

  function tick() {
    var now = new Date(), tg = target(), ms = Math.max(0, tg.t - now), s = Math.floor(ms / 1000);
    $("clock").textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) + " · " + now.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" });
    $("evName").textContent = ms === 0 ? "🎉 " + tg.name + " is here!" : "Until " + tg.name;
    $("d").textContent = Math.floor(s / 86400);
    $("h").textContent = pad(Math.floor(s % 86400 / 3600));
    $("m").textContent = pad(Math.floor(s % 3600 / 60));
    $("s").textContent = pad(s % 60);
    $("evDate").textContent = tg.t.toLocaleDateString([], { weekday: "long", year: "numeric", month: "long", day: "numeric" });
  }

  // Focus timer (runs while this tab is open).
  var running = false, onBreak = false, endAt = 0, left = cfg.flen * 60, done = 0, timerId = null;
  function brkLen() { return { 25: 5, 50: 10, 15: 3 }[cfg.flen] || 5; }
  function showTimer() {
    var secs = running ? Math.max(0, Math.round((endAt - Date.now()) / 1000)) : left;
    $("ftime").textContent = pad(Math.floor(secs / 60)) + ":" + pad(secs % 60);
    $("fmode").textContent = onBreak ? "Break" : "Focus";
    $("fmode").className = "fmode" + (onBreak ? " brk" : "");
    $("fstart").textContent = running ? "Pause" : "Start";
    $("fdone").textContent = done ? "Focus sessions done today: " + done : "";
    if (running) document.title = $("ftime").textContent + " · " + (onBreak ? "Break" : "Focus");
    else document.title = "New Tab";
    return secs;
  }
  function chime() {
    try {
      var ac = new (window.AudioContext || window.webkitAudioContext)();
      [0, 0.25].forEach(function (d, i) {
        var o = ac.createOscillator(), g = ac.createGain();
        o.frequency.value = i ? 880 : 660; o.connect(g); g.connect(ac.destination);
        g.gain.setValueAtTime(0.0001, ac.currentTime + d);
        g.gain.exponentialRampToValueAtTime(0.2, ac.currentTime + d + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + d + 0.6);
        o.start(ac.currentTime + d); o.stop(ac.currentTime + d + 0.65);
      });
    } catch (e) {}
  }
  function loop() {
    if (showTimer() <= 0) {
      chime();
      if (!onBreak) { done++; try { localStorage.setItem("ccDone", JSON.stringify({ d: new Date().toDateString(), n: done })); } catch (e) {} }
      onBreak = !onBreak; left = (onBreak ? brkLen() : cfg.flen) * 60; endAt = Date.now() + left * 1000;
    }
  }
  try { var dn = JSON.parse(localStorage.getItem("ccDone") || "null"); if (dn && dn.d === new Date().toDateString()) done = dn.n; } catch (e) {}
  $("fstart").onclick = function () {
    if (running) { left = Math.max(0, Math.round((endAt - Date.now()) / 1000)); running = false; clearInterval(timerId); }
    else { endAt = Date.now() + left * 1000; running = true; timerId = setInterval(loop, 250); }
    showTimer();
  };
  $("freset").onclick = function () { running = false; clearInterval(timerId); onBreak = false; left = cfg.flen * 60; showTimer(); };
  $("flen").value = String(cfg.flen);
  $("flen").onchange = function () { cfg.flen = +this.value; save(); $("freset").onclick(); };

  // Settings dialog.
  var dlg = $("settings");
  function syncCustom() { $("customFields").style.display = cfg.ev === "custom" ? "" : "none"; }
  $("gear").onclick = function () {
    dlg.querySelectorAll("input[name=ev]").forEach(function (r) { r.checked = r.value === cfg.ev; });
    $("cName").value = cfg.cName || ""; $("cDate").value = cfg.cDate || "";
    $("theme").value = cfg.theme; $("showSupport").checked = cfg.showSupport !== false;
    syncCustom(); dlg.showModal();
  };
  dlg.addEventListener("change", function () {
    var r = dlg.querySelector("input[name=ev]:checked"); cfg.ev = r ? r.value : "christmas";
    cfg.cName = $("cName").value.trim(); cfg.cDate = $("cDate").value;
    cfg.theme = $("theme").value; cfg.showSupport = $("showSupport").checked;
    save(); syncCustom(); applyTheme(); tick();
  });
  $("cName").addEventListener("input", function () { cfg.cName = this.value.trim(); save(); tick(); });

  applyTheme(); tick(); showTimer();
  setInterval(tick, 1000);
})();
